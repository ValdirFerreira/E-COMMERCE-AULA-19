﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Entities.Enums
{
    public enum TipoUsuario
    {
        Administrador = 1,
        Comum = 2
    }
}
